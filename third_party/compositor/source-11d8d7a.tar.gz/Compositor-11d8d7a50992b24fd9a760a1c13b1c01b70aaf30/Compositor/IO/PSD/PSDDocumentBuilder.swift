import CoreGraphics
import Foundation

nonisolated struct PSDImport: @unchecked Sendable {
    let width: Int
    let height: Int
    let resolution: Double
    let layers: [ImageLayer]
    let conversions: [PSDConversion]
}

nonisolated enum PSDDocumentBuilder {
    static func assets(from document: PSDDocument) throws -> [UUID: ImportedImage] {
        var result: [UUID: ImportedImage] = [:]
        for record in document.layers {
            guard let image = record.image else { continue }
            result[record.id] = try imported(image, name: record.name)
        }
        return result
    }

    @MainActor
    static func makeImport(_ document: PSDDocument, assets: [UUID: ImportedImage] = [:]) throws -> PSDImport {
        var conversions: [PSDConversion] = []
        var layers: [ImageLayer] = []
        let canvas = CGSize(width: document.width, height: document.height)
        for record in document.layers {
            if record.croppedToCanvas {
                conversions.append(PSDConversion(layerName: record.name,
                                                 message: "Cropped to the canvas so the file fits in memory. Pixels outside the canvas weren't imported."))
            }
            let renderedText = record.text.flatMap { try? PSDText.render($0) }
            var notes: [String] = []
            if record.kind == .text {
                if let source = record.text, renderedText != nil {
                    notes.append(contentsOf: source.notes)
                    if let missing = PSDText.missingFontNote(source.style.fontName) { notes.append(missing) }
                } else {
                    notes.append(PSDText.rasterizedNote)
                }
            }
            if record.kind == .smartObject {
                notes.append("The smart object was rasterized. Linked contents can’t be edited.")
            }
            if record.kind == .effects {
                notes.append("Layer effects were discarded, so the appearance may differ.")
            }
            if record.kind == .vector {
                if record.shape != nil {
                    notes.append(contentsOf: record.shapeNotes)
                } else {
                    notes.append("Vector shape was rasterized to pixels.")
                }
            }
            if record.kind == .other {
                notes.append("This Photoshop layer type isn’t supported and was imported as pixels.")
            }
            if record.isGroup {
                if record.blendKey != "pass" && record.blendKey != "norm" {
                    notes.append("Folder blend mode “\(record.blendKey)” isn’t supported. The folder will be pass-through.")
                }
            } else if record.blendMode == nil, record.blendKey != "pass" {
                notes.append("Blend mode “\(record.blendKey.trimmingCharacters(in: .whitespaces))” isn’t supported and will be applied as Normal.")
            }
            if record.kind == .adjustment {
                if record.adjustment == nil {
                    notes.append("This adjustment type isn’t supported and was skipped.")
                } else {
                    notes.append("Adjustment parameters may not match Photoshop exactly.")
                }
            }
            for note in notes {
                conversions.append(PSDConversion(layerName: record.name, message: note))
            }
            if record.kind == .adjustment, record.adjustment == nil { continue }
            var layer: ImageLayer
            if record.isGroup {
                // Folders carry an opacity of their own (1.1.6), which multiplies into what's inside
                // them just as Photoshop's group opacity does.
                layer = ImageLayer(id: record.id, asset: nil, name: record.name, isVisible: record.isVisible,
                                   transform: LayerTransform(origin: .zero, size: canvas), parentID: record.parentID,
                                   isGroup: true, opacity: min(1, max(0, record.opacity)))
            } else if let adjustment = record.adjustment {
                layer = ImageLayer(id: record.id, asset: nil, name: record.name, isVisible: record.isVisible,
                                   transform: LayerTransform(origin: .zero, size: canvas), parentID: record.parentID,
                                   opacity: min(1, max(0, record.opacity)),
                                   blendMode: record.blendMode ?? .normal, adjustment: adjustment)
            } else if let rendered = renderedText, let source = record.text {
                let asset = try imported(rendered.image, name: record.name)
                layer = ImageLayer(id: record.id, asset: asset, name: record.name, isVisible: record.isVisible,
                                   transform: rendered.transform, parentID: record.parentID,
                                   opacity: min(1, max(0, record.opacity)),
                                   blendMode: record.blendMode ?? .normal,
                                   text: LayerText(style: source.style, image: rendered.image))
            } else if let image = record.image {
                let asset = try assets[record.id] ?? imported(image, name: record.name)
                let origin = CGPoint(x: record.bounds.minX, y: record.bounds.minY)
                let size = record.bounds.size.width > 0 && record.bounds.size.height > 0
                    ? record.bounds.size
                    : CGSize(width: image.width, height: image.height)
                layer = ImageLayer(id: record.id, asset: asset, name: record.name, isVisible: record.isVisible,
                                   transform: LayerTransform(origin: origin, size: size), parentID: record.parentID,
                                   opacity: min(1, max(0, record.opacity)),
                                   blendMode: record.blendMode ?? .normal,
                                   shape: record.shape.map { LayerShape(style: $0, image: image) })
            } else {
                layer = ImageLayer(id: record.id, asset: nil, name: record.name, isVisible: record.isVisible,
                                   transform: LayerTransform(origin: .zero, size: canvas), parentID: record.parentID,
                                   opacity: min(1, max(0, record.opacity)),
                                   blendMode: record.blendMode ?? .normal)
            }
            if let maskImage = record.mask.flatMap({ Self.maskOnLayerGrid($0, record: record, layer: layer, canvas: canvas) }),
               let maskAsset = try? LayerMask.asset(from: maskImage) {
                layer.mask = LayerMask(asset: maskAsset, isEnabled: record.maskEnabled, isLinked: record.maskLinked)
            } else if record.mask != nil {
                conversions.append(PSDConversion(layerName: record.name, message: "The layer mask couldn’t be converted to 8-bit grayscale and was skipped."))
            }
            layers.append(layer)
        }
        let idToIndex = Dictionary(uniqueKeysWithValues: layers.enumerated().map { ($0.element.id, $0.offset) })
        var baseForParent: [UUID?: UUID] = [:]
        for record in document.layers {
            guard let index = idToIndex[record.id] else { continue }
            if record.clipping {
                if let source = baseForParent[record.parentID],
                   let sourceLayer = layers.first(where: { $0.id == source }),
                   !sourceLayer.isGroup, sourceLayer.adjustment == nil {
                    layers[index].maskSourceID = source
                } else {
                    conversions.append(PSDConversion(layerName: record.name, message: "This clipping mask’s base isn’t supported, so clipping was skipped."))
                }
            } else if let layer = idToIndex[record.id].map({ layers[$0] }), !layer.isGroup, layer.adjustment == nil {
                baseForParent[record.parentID] = record.id
            } else {
                baseForParent[record.parentID] = nil
            }
        }
        return PSDImport(width: document.width, height: document.height, resolution: document.resolution,
                         layers: layers, conversions: conversions)
    }

    private static func imported(_ image: CGImage, name: String) throws -> ImportedImage {
        ImportedImage(image: image, thumbnail: try PixelAdjust.thumbnail(of: image), name: name)
    }
}

extension PSDDocumentBuilder {
    /// A PSD layer mask on the layer's own pixel grid, as Compositor's masks are: the stored patch drawn where it sits
    /// on the document, and Photoshop's default value everywhere else. The patch alone, stretched over the layer, would
    /// put the mask in the wrong place. Adjustment layers and folders cover the canvas.
    nonisolated static func maskOnLayerGrid(_ patch: CGImage, record: PSDRecord, layer: ImageLayer, canvas: CGSize) -> CGImage? {
        let grid = layer.asset.map { CGSize(width: $0.image.width, height: $0.image.height) } ?? canvas
        let placed = CGRect(origin: layer.transform.origin, size: layer.transform.size)
        guard grid.width >= 1, grid.height >= 1, placed.width > 0, placed.height > 0,
              record.maskBounds.width > 0, record.maskBounds.height > 0 else { return patch }
        let scaleX = grid.width / placed.width, scaleY = grid.height / placed.height
        let rect = CGRect(x: (record.maskBounds.minX - placed.minX) * scaleX, y: (record.maskBounds.minY - placed.minY) * scaleY,
                          width: record.maskBounds.width * scaleX, height: record.maskBounds.height * scaleY)
        // Already the layer's grid: nothing to place.
        if rect.integral == CGRect(origin: .zero, size: grid), patch.width == Int(grid.width), patch.height == Int(grid.height) { return patch }
        let width = Int(grid.width), height = Int(grid.height)
        guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width,
                                      space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return nil }
        context.setFillColor(gray: CGFloat(record.maskDefault) / 255, alpha: 1)
        context.fill(CGRect(x: 0, y: 0, width: width, height: height))
        context.interpolationQuality = .none
        // Top-left document rows, bottom-up context rows.
        context.draw(patch, in: CGRect(x: rect.minX, y: CGFloat(height) - rect.maxY, width: rect.width, height: rect.height))
        return context.makeImage()
    }
}
